import React from 'react'
import Na from "./Na";
import Side from "./Side";

function Click() {
    return (
        <>
            {/* <Na /> */}
            {/* <Side /> */}
        </>
    )
}

export default Click
